package com.example.timer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    private ImageButton playButton,pauseButton,resetButton;
    private TextView previousTime;
    private Boolean isRunning;
    private long timePaused;
    private Chronometer chronometer;
    private EditText taskName;
    private String task;
    private String previousTask;
    private String previousTimeamount;
    private String previousTaskandTime;
    private long currentTime;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences sharedPreferences=getSharedPreferences("firstPref",MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();




        playButton=findViewById(R.id.playButton);
        pauseButton=findViewById(R.id.pauseButton);
        resetButton=findViewById(R.id.resetButton);
        chronometer=findViewById(R.id.simpleChronometer);
        previousTime=findViewById(R.id.textView2);
        taskName=findViewById(R.id.enterTask);
        task=taskName.getText().toString();
        isRunning=false;


        previousTime.setText(sharedPreferences.getString("prevText",null));

        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isRunning.equals(false)){

                    chronometer.setBase(SystemClock.elapsedRealtime()-timePaused);
                    chronometer.start();
                    isRunning=true;
                }

            }
        });
        pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isRunning.equals(true)){

                    chronometer.stop();
                    timePaused=SystemClock.elapsedRealtime()-chronometer.getBase();
                    isRunning=false;
                }

            }
        });
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                previousTask=task;
                previousTimeamount=chronometer.getText().toString();
                chronometer.setBase(SystemClock.elapsedRealtime());
                timePaused=0;
                String prevText="Time Spent on "+previousTask+" is "+previousTimeamount;
                previousTaskandTime=prevText;

                editor.putString("prevText",previousTaskandTime);
                editor.apply();
                previousTime.setText(prevText);

            }
        });
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        EditText txt=(EditText) findViewById(R.id.enterTask);
        Chronometer chrono=findViewById(R.id.simpleChronometer);
        TextView previousT=findViewById(R.id.textView2);

        String taskName=txt.getText().toString();
        long time=SystemClock.elapsedRealtime()-timePaused;
        String previousInfo=previousT.getText().toString();
        long timeS=chronometer.getBase();
        outState.putLong("timeP",timePaused);
        outState.putString("taskName",taskName);
        outState.putLong("time",time);
        outState.putString("previousInfo",previousInfo);
        outState.putBoolean("isRunning",isRunning);
        outState.putLong("timePaused",timeS);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        String taskNam= savedInstanceState.getString("taskName");
        long time= savedInstanceState.getLong("time");
        String previousInfo=savedInstanceState.getString("previousInfo");
        chronometer=findViewById(R.id.simpleChronometer);
        previousTime=findViewById(R.id.textView2);
        taskName=findViewById(R.id.enterTask);
        isRunning=savedInstanceState.getBoolean("isRunning");
        long timeS= savedInstanceState.getLong("timePaused");
        timePaused= savedInstanceState.getLong("timeP");
        if(isRunning){
            chronometer.setBase(timeS);
            chronometer.start();
            isRunning=true;
        }
        else{
            chronometer.setBase(time);
            chronometer.stop();
            isRunning=false;
        }



        previousTime.setText(previousInfo);
        taskName.setText(taskNam);

    }
}